package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBConnection {
    
    private static final String URL = "jdbc:derby://localhost:1527/student_profiles;create=true";
    private static final String USER = "app";
    private static final String PASS = "app";
    
    static {
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            System.out.println("✅ JavaDB Driver Loaded");
        } catch (ClassNotFoundException e) {
            System.err.println("❌ JavaDB Driver not found!");
            e.printStackTrace();
        }
    }
    
    public static Connection getConnection() {
        Connection conn = null;
        try {
            System.out.println("🔗 Connecting to: " + URL);
            conn = DriverManager.getConnection(URL, USER, PASS);
            System.out.println("✅ Connected to: student_profiles database");
            
            checkAndCreateTable(conn);
            
            return conn;
            
        } catch (SQLException e) {
            System.err.println("❌ Database connection FAILED!");
            System.err.println("Error: " + e.getMessage());

            if (e.getMessage().contains("Database") && e.getMessage().contains("not found")) {
                System.err.println("\n⚠️  Database 'student_profiles' doesn't exist!");
                System.err.println("Please create it in NetBeans:");
                System.err.println("1. Services tab → Databases → JavaDB");
                System.err.println("2. Right-click → Create Database...");
                System.err.println("3. Name: student_profiles, User: app, Password: app");
            }
            
            e.printStackTrace();
            return null;
        }
    }
    
    private static void checkAndCreateTable(Connection conn) {
        System.out.println("\n=== CHECKING PROFILE TABLE ===");
        
        try {
            Statement stmt = conn.createStatement();

            try {
                ResultSet rs = stmt.executeQuery("SELECT * FROM APP.PROFILE");
                System.out.println("✅ Found PROFILE table in APP schema");

                ResultSet countRs = stmt.executeQuery("SELECT COUNT(*) as total FROM APP.PROFILE");
                if (countRs.next()) {
                    System.out.println("📊 Existing records: " + countRs.getInt("total"));
                }
                countRs.close();
                rs.close();
                
            } catch (SQLException e) {
                System.out.println("ℹ️  PROFILE table not found, creating it...");
                
                String createTableSQL = 
                    "CREATE TABLE APP.PROFILE (" +
                    "id INTEGER NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1), " +
                    "student_id VARCHAR(20) NOT NULL, " +
                    "name VARCHAR(100) NOT NULL, " +
                    "email VARCHAR(100), " +
                    "programme VARCHAR(100), " +
                    "hobby VARCHAR(200), " +
                    "PRIMARY KEY (id), " +
                    "CONSTRAINT unique_student_id UNIQUE (student_id)" +
                    ")";
                
                stmt.executeUpdate(createTableSQL);
                System.out.println("✅ Created APP.PROFILE table");

                String[] insertSQLs = {
                    "INSERT INTO APP.PROFILE (student_id, name, email, programme, hobby) VALUES " +
                    "('CS001', 'Ali Ahmad', 'ali@email.com', 'Computer Science', 'Programming, Gaming')",
                    
                    "INSERT INTO APP.PROFILE (student_id, name, email, programme, hobby) VALUES " +
                    "('CS002', 'Siti Sarah', 'siti@email.com', 'Software Engineering', 'Reading, Cooking')",
                    
                    "INSERT INTO APP.PROFILE (student_id, name, email, programme, hobby) VALUES " +
                    "('CS003', 'Raj Kumar', 'raj@email.com', 'Data Science', 'Sports, Photography')"
                };
                
                int inserted = 0;
                for (String sql : insertSQLs) {
                    try {
                        stmt.executeUpdate(sql);
                        inserted++;
                    } catch (SQLException insertErr) {
                        System.out.println("⚠️  Could not insert: " + insertErr.getMessage());
                    }
                }
                
                if (inserted > 0) {
                    System.out.println("✅ Inserted " + inserted + " sample records");
                }
            }
            
            stmt.close();
            
        } catch (SQLException e) {
            System.err.println("❌ Error with table: " + e.getMessage());
            e.printStackTrace();
        }
        
        System.out.println("=== TABLE CHECK COMPLETE ===\n");
    }
    
    // Test the connection to THIS database
    public static void main(String[] args) {
        System.out.println("=== TESTING student_profiles DATABASE ===");
        
        try (Connection conn = getConnection()) {
            if (conn != null) {
                Statement stmt = conn.createStatement();
                
                // Count records
                ResultSet rs = stmt.executeQuery("SELECT COUNT(*) as total FROM APP.PROFILE");
                if (rs.next()) {
                    System.out.println("📊 Total records in APP.PROFILE: " + rs.getInt("total"));
                }
                rs.close();
                
                // Show all data
                System.out.println("\n=== ALL PROFILES in student_profiles DATABASE ===");
                rs = stmt.executeQuery("SELECT * FROM APP.PROFILE ORDER BY id");
                
                System.out.println("ID | Student ID | Name | Email | Programme | Hobbies");
                System.out.println("--------------------------------------------------------");
                
                while (rs.next()) {
                    System.out.printf("%-3d | %-10s | %-15s | %-20s | %-20s | %s%n",
                        rs.getInt("id"),
                        rs.getString("student_id"),
                        rs.getString("name"),
                        rs.getString("email"),
                        rs.getString("programme"),
                        rs.getString("hobby"));
                }
                
                rs.close();
                stmt.close();
                
                System.out.println("\n✅ student_profiles database is READY!");
            } else {
                System.err.println("❌ Connection failed - returned null");
            }
        } catch (Exception e) {
            System.err.println("❌ Test failed: " + e.getMessage());
            e.printStackTrace();
        }
    }
}